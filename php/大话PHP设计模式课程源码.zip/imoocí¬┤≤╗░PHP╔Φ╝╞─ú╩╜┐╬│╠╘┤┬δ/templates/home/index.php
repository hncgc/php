<h1>
    hello <?=$name?>
</h1>