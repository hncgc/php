<?php
namespace App\Observer;

class UserAdd2
{
    function update($id)
    {
        echo "注册社保<br/>";;
    }
}