<?php
namespace App\Observer;

class UserAdd4
{
    function update($id)
    {
        echo "逻辑<br/>";
    }
}