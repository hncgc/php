<?php
namespace App\Observer;

class UserAdd3
{
    function update($id)
    {
        echo "分配电脑<br/>";
    }
}