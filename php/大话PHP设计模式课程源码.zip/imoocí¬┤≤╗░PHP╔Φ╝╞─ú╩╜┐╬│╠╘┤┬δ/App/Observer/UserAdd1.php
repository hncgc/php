<?php
namespace App\Observer;

class UserAdd1
{
    function update($id)
    {
        echo "分配工位<br/>";
    }
}