<?php
namespace App\Controller;
use IMooc\Controller;
use IMooc\Factory;

class Login extends Controller
{
    function index()
    {
        echo "<h1>Login page</h1>";
    }
}