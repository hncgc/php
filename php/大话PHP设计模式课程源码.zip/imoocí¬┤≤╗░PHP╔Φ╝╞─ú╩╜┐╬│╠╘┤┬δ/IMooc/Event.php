<?php
/**
 * Created by PhpStorm.
 * User: htf
 * Date: 14-11-20
 * Time: 上午12:12
 */

namespace IMooc;


class Event {

} 