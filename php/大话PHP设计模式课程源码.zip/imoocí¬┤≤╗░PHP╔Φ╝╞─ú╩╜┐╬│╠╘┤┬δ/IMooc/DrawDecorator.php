<?php
namespace IMooc;

interface DrawDecorator
{
    function beforeDraw();
    function afterDraw();
}