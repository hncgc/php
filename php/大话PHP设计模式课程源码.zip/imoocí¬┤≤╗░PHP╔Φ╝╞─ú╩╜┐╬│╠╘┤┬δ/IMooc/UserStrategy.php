<?php
/**
 * Created by PhpStorm.
 * User: htf
 * Date: 14-11-3
 * Time: 下午11:31
 */

namespace IMooc;


interface UserStrategy {
    function showAd();
    function showCategory();
} 